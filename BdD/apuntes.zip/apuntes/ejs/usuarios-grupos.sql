select user();

SELECT CURRENT_USER();

DESCRIBE mysql.user;

SELECT User, Host, authentication_string FROM mysql.user;

select * from jardineria;