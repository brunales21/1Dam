Componentes del grupo: Monica Delgado Capellán y Bruno Mercado Sarsano.

Ide utilizado: IntellijIDEA
JDK: Java 8

nota: en la carpeta de ejecutables, el fichero "palabrasDificiles.txt" es equivalente al fichero que contiene todas las palabras del diccionario.

Cumple con las condiciones de la rubrica.
Hemos implementado 3 niveles (tres ficheros diferentes con palabras que corresponden con las dificulades), se muestra el highestScore de la partida
y la cantidad de POKEs usados. Además, si se introduce "x" se abandona la partida actual.
El sistema "POKE" muestra letras que faltan en el intento actual. Si no quedan pokes en ese intento (hemos obligado que se de ese caso
para que no repita las mismas pistas varias veces), se indica por pantalla.

