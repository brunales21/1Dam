Integrantes del grupo: Mónica Delgado Capellán, Bruno Emiliano Mercado Sarsano
SDK: java 11.0.17
IDE: IntellijIDEA Community Edition
Importante: Ejecutar en Git bash para una mejor experiencia. (se visualiza mejor, se sigue mejor el hilo de la partida...etc)
El ejecutable del juego es Main.class
